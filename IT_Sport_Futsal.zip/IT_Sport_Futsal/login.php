<?php 
include 'config.php';
session_start();
// cek session if true otw welcome.php
if (isset($_SESSION['username'])) {
        header("Location: welcome.php");
    }

    if(isset($_POST["login"]))  
 {  
      if(empty($_POST["username"]) || empty($_POST["password"]))  
      {  
           echo '<script>alert("Both Fields are required")</script>';  
      }  
      else  
      {  
           $username = mysqli_real_escape_string($con, $_POST["username"]);  
           $password = mysqli_real_escape_string($con, $_POST["password"]);  
           $query = "SELECT * FROM login WHERE userName = '$username'";  
           $result = mysqli_query($con, $query);  
           if(mysqli_num_rows($result) > 0)  
           {  
                while($row = mysqli_fetch_array($result))  
                {  
                     if(password_verify($password, $row["password"]))  
                     {  
                          //return true;  
                          $_SESSION['status'] = $row['status'];

                          if ($_SESSION['status'] == 'superman') {
                          $_SESSION["superman"] = $status;  
                          $_SESSION["login"] = $username;  
                          $_SESSION['id']=$row['id']; // get dari mysqli fetch array
                          $uip=$_SERVER['REMOTE_ADDR']; // get the user ip
                          $action="Login";  
                          mysqli_query($con,"insert into userlog(userId,username,userIp,action) values('".$_SESSION['id']."','".$_SESSION['login']."','$uip','$action')");
                          $extra="index.php";
                          $host=$_SERVER['HTTP_HOST'];
                          $uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
                          header("location:http://$host$uri/$extra");
                          exit();
                          }elseif ($_SESSION['status'] == 'batman') {
                          $_SESSION["batman"] = $status;  
                          $_SESSION["login"] = $username;  
                          $_SESSION['id']=$row['id']; // get dari mysqli fetch array
                          $uip=$_SERVER['REMOTE_ADDR']; // get the user ip
                          $action="Login";  
                          mysqli_query($con,"insert into userlog(userId,username,userIp,action) values('".$_SESSION['id']."','".$_SESSION['login']."','$uip','$action')");
                          $extra="pengunjung.php";
                          $host=$_SERVER['HTTP_HOST'];
                          $uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
                          header("location:http://$host$uri/$extra");
                          exit();
                          }else{
                             echo '<script>alert("Maaf anda tidak punya hak akses")</script>';
                          }
                          
                     }  
                     else  
                     {  
                          //return false;  
                          echo '<script>alert("User / password Anda salah")</script>';  
                     }  
                }  
           }  
           else  
           {  
                echo '<script>alert("user / password lu ga tersedia")</script>';  
           }  
      }  
 }  
  


 ?>
