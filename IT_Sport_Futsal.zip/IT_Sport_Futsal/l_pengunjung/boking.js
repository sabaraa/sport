
//  for select / deselect all
//  dynamically redirects to specified page
function lapangan1() 
{
 document.frm.action = "./pengunjung.php";
 document.frm.submit();  
}
function lapangan2() 
{
 document.frm.action = "./pengunjung.php";
 document.frm.submit();  
}
function lapangan3() 
{
 document.frm.action = "./pengunjung.php";
 document.frm.submit();  
}
