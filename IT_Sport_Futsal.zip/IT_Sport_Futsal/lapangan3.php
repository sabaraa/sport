
<?php  
  include 'koneksi.php';
   session_start();
 
    // cek apakah yang mengakses halaman ini sudah login
    if($_SESSION['status']=="superman"){
        
    }else{
        header("location:masuk.php?pesan=gagal");
}
  date_default_timezone_set('Asia/Jakarta');
  $now    = date ("d-m-Y");
 ?> 
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bootstrap Order Details Table with Search Filter</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="boking.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
</head>
<body>
    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-4">
            <h2>Lapangan<b> 3</b></h2>
          </div>
          <div class="col-sm-offset-11">
                        <span class="btn btn-success">Waktu Sekarang : <?php  echo $now; ?></span>
          </div>
                </div>
            </div>
      <div class="table-filter">
        <div class="row">
                    <div class="col-sm-3">
            <div class="show-entries">
              <?php  if(isset($_GET['tanggal'])){
                             echo "tangal pilihan anda : ". $tgl = $_GET['tanggal'];
                                 }
                                     else{
                                     echo "Data Tanggal : ".$now;
               
                                    }
            
                                ?>
            </div>
          </div>
                    <form method="get"> 
                     <div class="col-sm-9">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                        <div class="filter-group">
                            <label>Cari Tanggal main :</label>
                            <input type="date" class="form-control" name="tanggal" required>
                        </div>                      
                     </div>
                    </form>
                </div>
            </div>

  <form method="post" name="frm">
  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>Tanggal</th>
          <th>Jam</th>
          <th>Lapangan</th>
          <th>status</th>
          <th>Pilih</th>
        </tr>
      </thead>
      <tbody>
        <?php 
         date_default_timezone_set('Asia/Jakarta');
         $now    = date ("Y-m-d");
         $sql = $koneksi->query("SELECT * FROM jadwal,detail_jadwal WHERE jadwal.id_jadwal = detail_jadwal.id_jadwal AND jadwal.tanggal = '$now'");
         $count = $sql->num_rows;
         if ($count > 0) {
               
             }   
             if(isset($_GET['tanggal']) > 0){   
                $tgl = $_GET['tanggal'];
                $sql = mysqli_query($koneksi,"SELECT * FROM jadwal,detail_jadwal WHERE jadwal.id_jadwal=detail_jadwal.id_jadwal AND jadwal.tanggal LIKE '%$tgl%'");
            }else{
                $sql = mysqli_query($koneksi,"SELECT * FROM jadwal,detail_jadwal WHERE jadwal.id_jadwal = detail_jadwal.id_jadwal AND jadwal.tanggal = '$now'");
          
            }
            
            while($data = mysqli_fetch_array($sql)){ ?>
        <tr>
          <?php if ($data['lapangan3'] == 'ada'){
                ?>
                <td>#</td>
                <td><?php  echo $data['tanggal']; ?></td>
                <td><?php  echo $data['jam']; ?></td>
                <td>Lapangan 3</td>
                <td><span class="status text-info">&bull;</span> Kosong</td>
                <td><input type="checkbox" name="chk[]" class="chk-box" value="<?php echo $data['id_detail']; ?>"/></td>
                <?php
            }else{
              ?>
                <td>#</td>
                <td><?php  echo $data['tanggal']; ?></td>
                <td><?php  echo $data['jam']; ?></td>
                <td>Lapangan 3</td>
                <td><span class="status text-danger">&bull;</span> Penuh</td>
                <td><input type="checkbox" name="chk[]" class="chk-box" value="<?php echo $data['id_detail']; ?>" disabled/></td>
                <?php
             }?>
            
            
        
     <?php  } ?>
     <?php
       if($count > 0)
      {
      ?>
 
      <?php
        }
        ?>

      <?php  
                if (isset($tgl)==0) {
                    echo "<font color=red><blink>Cari Tanggal booking!</blink></font>";
                }elseif (mysqli_num_rows($sql) == 0) {
                    echo "<center>'<h1>'<font color=red><blink>Tidak dapat menampilkan data berdasarkan tanggal Yg di Pilih !</blink></font>'</h1>'</center>";
                }


             ?>
          
        </tr>
      </tbody>
    </table>
      <div class="clearfix">
        <button type="submit" name="pesan" class="btn btn-primary" onClick="lapangan3();">
          pesan
        </button>
      </div>
      <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Developer &copy; 2019 - Teguh Sabara</div>
    </div>
  </footer>
  </div>
</div> 

</body>
</form>
</html>                                                               
