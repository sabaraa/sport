
//  for select / deselect all
//  dynamically redirects to specified page
function lapangan1() 
{
 document.frm.action = "boking1.php";
 document.frm.submit();  
}
function lapangan2() 
{
 document.frm.action = "boking2.php";
 document.frm.submit();  
}
function lapangan3() 
{
 document.frm.action = "boking3.php";
 document.frm.submit();  
}
function delete_records() 
{
 document.frm.action = "delete_mul.php";
 document.frm.submit();
}