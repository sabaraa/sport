<?php 
	session_start();
 
	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['status']=="batman"){
		
	}else{
		header("location:index.php?pesan=gagal");
	}
 
	?>
<html>
<head>
	<title>Admin Area | tutorialweb.net</title>
</head>
<body>
 
	<div style="text-align:center">
		<h2>Admin Area</h2>
		<p><a href="../masuk.php">Home</a> / <a href="../logout.php">Logout</a></p>
 
		<p>Selamat datang di Admin Area, Anda Login dengan Sebagai <?php echo $_SESSION['status']; ?></p>
		<p>user</p>
	</div>
 
</body>
</html>