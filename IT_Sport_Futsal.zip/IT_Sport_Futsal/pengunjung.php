<?php 
 include 'config.php';
 session_start();
 
    // cek apakah yang mengakses halaman ini sudah login
    if($_SESSION['status']=="batman"){
        
    }else{
        header("location:masuk.php?pesan=gagal");
}



 ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>IT Sport Center</title>

  <!-- Font Awesome Icons -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

  <!-- Plugin CSS -->
  <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

  <!-- Theme CSS - Includes Bootstrap -->
  <link href="css/creative.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/harga.css">
  


</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">IT Sport Center</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto my-2 my-lg-0">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#services">Fasilitas</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#portfolio">Gambar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#contact">kontak</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Masthead -->
  <header class="masthead" id="about">
    <div class="container h-100">
      <div class="row h-100 align-items-center justify-content-center text-center">
        <div class="col-lg-10 align-self-end">
          <h3 class="text-uppercase text-white font-weight-bold">Freekick mengajarkan ku jika jarak bukan suatu halangan untuk mencapai tujuan.</h3>
          <hr class="divider my-4">
        </div>
        <div class="col-lg-8 align-self-baseline">
          <p class="text-white-75 font-weight-light mb-5">“Tidak apa – apa jomblo, yang penting main futsalnya jago.”</p>
           <p class="text-white-75 font-weight-light mb-5">Developer By : Teguh Sabara</p>
        </div>
      </div>
    </div>
  </header>
  <!-- Services Section -->
  <section class="page-section" id="services">
    <div class="container">
      <h2 class="text-center mt-0">Fasilitas</h2>
      <hr class="divider my-4">
      <div class="row">
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-wifi text-primary mb-4"></i>
            <h3 class="h4 mb-2">Gratis Wifi</h3>
            <p class="text-muted mb-0">Menyediakan fasilitas layanan wifi gratis untuk Pengunjung.</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-utensils text-primary mb-4"></i>
            <h3 class="h4 mb-2">Kantin</h3>
            <p class="text-muted mb-0">Menyediakan fasilitas kantin untuk Pengunjung.</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-chair text-primary mb-4"></i>
            <h3 class="h4 mb-2">Bangku penonton</h3>
            <p class="text-muted mb-0">Menyediakan fasilitas berupa bangku Penonton disetiap Lapangan.</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-toilet text-primary mb-4"></i>
            <h3 class="h4 mb-2">Wc umum</h3>
            <p class="text-muted mb-0">Menyediakan fasilitas WC umum yg bersih dan aman untuk Pengunjung.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Portfolio Section -->
  <section id="portfolio">
    <div class="container-fluid p-0">
      <div class="row no-gutters">
        <div class="col-lg-4 col-sm-6">
          <a class="portfolio-box" href="img/portfolio/fullsize/taraflex.png">
            <img class="img-fluid" src="img/portfolio/fullsize/taraflex.png" alt="">
            <div class="portfolio-box-caption">
              <div class="project-category text-white-50">
                Lapangan 1
              </div>
              <div class="project-name">
                Lapangan Taraflex
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-4 col-sm-6">
          <a class="portfolio-box" href="img/portfolio/fullsize/parquete.png">
            <img class="img-fluid" src="img/portfolio/fullsize/parquete.png" alt="">
            <div class="portfolio-box-caption">
              <div class="project-category text-white-50">
               Lapangan 2
              </div>
              <div class="project-name">
                Lapangan Parquette
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-4 col-sm-6">
          <a class="portfolio-box" href="img/portfolio/fullsize/sintetis.png">
            <img class="img-fluid" src="img/portfolio/fullsize/sintetis.png" alt="">
            <div class="portfolio-box-caption">
              <div class="project-category text-white-50">
                Lapangan 3
              </div>
              <div class="project-name">
               Lapangan Sintetis
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-4 col-sm-6">
          <a class="portfolio-box" href="img/portfolio/fullsize/tribun.png">
            <img class="img-fluid" src="img/portfolio/fullsize/tribun.png" alt="">
            <div class="portfolio-box-caption">
              <div class="project-category text-white-50">
                Fasilitas Lainnya
              </div>
              <div class="project-name">
                Bangku Penonton
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-4 col-sm-6">
          <a class="portfolio-box" href="img/portfolio/fullsize/kantin.png">
            <img class="img-fluid" src="img/portfolio/fullsize/kantin.png" alt="">
            <div class="portfolio-box-caption">
              <div class="project-category text-white-50">
                Fasilitas Lainnya
              </div>
              <div class="project-name">
                Kantin 
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-4 col-sm-6">
          <a class="portfolio-box" href="img/portfolio/fullsize/wc.png">
            <img class="img-fluid" src="img/portfolio/fullsize/wc.png" alt="">
            <div class="portfolio-box-caption p-3">
              <div class="project-category text-white-50">
                Fasilitas Lainnya
              </div>
              <div class="project-name">
                WC Umum
              </div>
            </div>
          </a>
        </div>
      </div>
    </div>
  </section>


  <!-- harga -->
  <section class="page-section">
    <h2 class="text-center mt-0">Daftar Harga</h2>
    <div class="badan">

        <div class="tabel-harga">
            <div class="header header-gratis">
                <span class="paket">Lapangan 1</span>
                <span class="harga">Rp.50.000,-</span>
            </div>
 
            <ul>
                <li>Waktu : 60 Menit</li>
                <li>Lapangan taraflex</li>
                <li>Didalam Ruangan</li>
                <li>2 bola futsal</li>
            </ul>
 
            <div class="ruang-tombol">
                <a href="l_pengunjung/lapangan1.php" class="selengkapnya header-gratis">Lihat jadwal</a>
            </div>
        </div>
 
        <div class="tabel-harga">
            <div class="header header-premium">
                <span class="paket">Lapangan 2</span>
                <span class="harga">Rp.70.000,-</span>
            </div>
 
            <ul>
                <li>Waktu : 60 Menit</li>
                <li>lapangan parquette</li>
                <li>Didalam Ruangan</li>
                <li>2 bola futsal</li>
            </ul>
 
            <div class="ruang-tombol">
                <a href="l_pengunjung/lapangan2.php" class="selengkapnya header-premium">Lihat jadwal</a>
            </div>
        </div>
 
        <div class="tabel-harga">
            <div class="header header-profesional">
                <span class="paket">Lapangan 3</span>
                <span class="harga">Rp 100.000,-</span>
            </div>
 
            <ul>
                <li>Waktu : 60 Menit</li>
                <li>Lapangan rumput sintetis</li>
                <li>Didalam Ruangan</li>
                <li>3 bola futsal</li>
            </ul>
 
            <div class="ruang-tombol">
                <a href="l_pengunjung/lapangan3.php" class="selengkapnya header-profesional">Lihat jadwal</a>
            </div>
        </div>
    </div>
  </section>

  <!-- Call to Action Section -->
  <section class="page-section bg-dark text-white">
    <div class="container text-center">
      <h2 class="mb-4" >Denah Lokasi IT Sport Futsal</h2>
      <div id="googleMap" style="width:100%;height:300px;"></div><br> 
      <a class="btn btn-light btn-xl" href="https://www.google.com/maps/place/Berkah+Pulsa/@-6.4033561,106.8957225,17z/data=!4m5!3m4!1s0x2e69eb3ebbf1c6ab:0xf8ab9b44517c6063!8m2!3d-6.4033717!4d106.8934808">Detail Lokasi</a>
    </div>
  </section>

  <!-- Contact Section -->
  <section class="page-section" id="contact">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="mt-0">kontak Kami</h2>
          <hr class="divider my-4">
          <p class="text-muted mb-5">Untuk info lebih lanjut bisa coba coba hubungi kontak di bawah ini heheh terima kasih!</p>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
          <i class="fas fa-phone fa-3x mb-3 text-muted"></i>
          <a class="d-block" href="https://wa.me/6285893014133"></a>
          <div>+62 (858) 9301-14133</div>
        </div>
        <div class="col-lg-4 mr-auto text-center">
          <i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
          <!-- Make sure to change the email address in anchor text AND the link below! -->
          <a class="d-block" href="mailto:teguhsabara0405@gmail.com"></a>
          <div>teguhsabara0405@gmail.com</div>
        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Template Copyright &copy; 2019 - Start Bootstrap | Developer By &copy; 2019 - Teguh Sabara</div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/creative.min.js"></script>
  <script src="http://maps.googleapis.com/maps/api/js"></script>
  <script>
        // fungsi initialize untuk mempersiapkan peta
        function initialize() {
        var propertiPeta = {
            center:new google.maps.LatLng(-6.4033561,106.8957225),
            zoom:9,
            mapTypeId:google.maps.MapTypeId.ROADMAP
        };
        
        var peta = new google.maps.Map(document.getElementById("googleMap"), propertiPeta);
        }

        // event jendela di-load  
        google.maps.event.addDomListener(window, 'load', initialize);
    </script>

</body>

</html>
