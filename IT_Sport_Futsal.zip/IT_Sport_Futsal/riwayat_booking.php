
<?php  
  include 'koneksi.php';
   session_start();
 
    // cek apakah yang mengakses halaman ini sudah login
    if($_SESSION['status']=="superman"){
        
    }else{
        header("location:index.php?pesan=gagal");
}
  date_default_timezone_set('Asia/Jakarta');
  $now    = date ("Y-m-d");
 ?> 
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Riwayat Booking</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="boking.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
</head>
<body>
    <div class="container-fluid">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-4">
            <h2>Riwayat Booking <b></b></h2>
          </div>
          <div class="col-sm-offset-11">
                        <span class="btn btn-success">Waktu Sekarang : <?php  echo $now; ?></span>
          </div>
                </div>
            </div>
      <div class="table-filter">
        <div class="row">
                    <div class="col-sm-3">
            <div class="show-entries">
              <?php  if(isset($_GET['qr_booking'])){
                             echo "tangal pilihan anda : ". $qr_booking = $_GET['qr_booking'];
                                 }
                                     else{
                                     echo "Data Booking Tanggal : ".$now;
               
                                    }
            
                                ?>
            </div>
          </div>
                    <form method="get"> 
                     <div class="col-sm-9">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                        <div class="filter-group">
                            <label>QR_booking :</label>
                            <input type="text" class="form-control" name="qr_booking" required>
                        </div>                      
                     </div>
                    </form>
                </div>
            </div>

  <form method="post" name="frm">
  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
        <tr>
          <!-- <th>ID BOKING</th> -->
          <th>QR QODE</th>
          <th>F_NAME</th>
          <th>T_Name</th>
          <th>T_Booking </th>
          <th>T_MAIN</th>
          <th>Harga</th>
          <!-- <th>J_MAIN</th> -->
          <th>T_harga</th>
          <th>B_awal</th>
          <th>aksi</th>
          
        </tr>
      </thead>
      <tbody>
        <?php 
        $sql = mysqli_query($koneksi,"SELECT * FROM boking WHERE j_main IN(SELECT max(j_main) FROM boking) ");
        if(isset($_GET['qr_booking']) > 0){   
                $qr = $_GET['qr_booking'];
                $sql = mysqli_query($koneksi,"SELECT DISTINCT qr_booking,f_name,nama_tim,t_booking,t_main,h_lapangan,t_harga,b_awal FROM boking WHERE qr_booking='$qr'");
            }else{
                $sql = mysqli_query($koneksi,"SELECT DISTINCT qr_booking,f_name,nama_tim,t_booking,t_main,h_lapangan,t_harga,b_awal FROM boking order by id_boking DESC;");
          
            }
          while($d = mysqli_fetch_array($sql)){
         ?>
        <tr>
          <!-- <td><?php echo $d['id_boking']; ?></td> -->
          <td><?php echo $d['qr_booking']; ?></td>
          <td><?php echo $d['f_name']; ?></td>
          <td><?php echo $d['nama_tim']; ?></td>
          <td><?php echo $d['t_booking']; ?></td>
          <td><?php echo $d['t_main']; ?></td>
          <td><?php echo $d['h_lapangan']; ?></td>
          <!-- <td><?php echo $d['j_main']; ?></td> -->
           <?php 
             if ($d['t_harga'] == $d['b_awal']) {
                ?>
                <td style="color: blue;"><?php echo $d['t_harga']; ?></td>
                <td style="color: blue;"><?php echo $d['b_awal']; ?></td>
                <?php
             }else{
                ?>
                <td style="color: red;"><?php echo $d['t_harga']; ?></td>
                <td style="color: red;"><?php echo $d['b_awal']; ?></td>
                <?php
             }
             ?>
          <td>
            <div class="dropdown">
             <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" style="background: green">-pilih-
              <span class="caret"></span></button>
              <ul class="dropdown-menu">
               <li><a href="detail1.php?qr_booking=<?php echo $d['qr_booking']; ?>">Detail</a></li>
               <li><a href="fpdf.php?qr_booking=<?php echo $d['qr_booking']; ?>">Cetak Pdf</a></li>
              </ul>
            </div>
          </td>  
          
        </tr>
      <?php } ?>
      <?php  
                if (isset($qr)== 0) {
                    echo "<font color=red><blink>Cari QR_booking User!</blink></font>";
                }elseif (mysqli_num_rows($sql) == 0) {
                    echo "<center>'<h1>'<font color=red><blink>Tidak dapat menampilkan data berdasarkan tanggal Yg di Pilih !</blink></font>'</h1>'</center>";
                }


             ?>
      </tbody>
    </table>
    <hr> 
      <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Developer &copy; 2019 - Teguh Sabara</div>
    </div>
  </footer>
  </div>
</div> 

</body>
</form>
</html>                                                               
