<?php

include 'koneksi.php';

// Koneksi library FPDF
require('FPDF/fpdf.php');
// Setting halaman PDF
$pdf = new FPDF('p','mm','A4');
// Menambah halaman baru
$pdf->AddPage('l');
// Setting jenis font
$pdf->SetFont('Arial','B',16);
// Membuat string
$pdf->Cell(10,7,'',0,1);
$pdf->Cell(280,7,'Riwayat Booking Lapangan 1',0,1,'C');
$pdf->SetFont('Arial','B',9);
$pdf->Cell(280,7,'Jl. Abece No. 80 Kodamar, jakarta Utara.',0,1,'C');
// Setting spasi kebawah supaya tidak rapat
$pdf->Cell(10,7,'',0,1);
$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Arial','B',10);
// $pdf->Cell(10,6,'Lapangan',1,0);
$pdf->Cell(40,6,'QR Code',1,0);
$pdf->Cell(43,6,'Firstname',1,0);
$pdf->Cell(43,6,'Lastname',1,0);
$pdf->Cell(35,6,'T_Booking',1,0);
$pdf->Cell(35,6,'T_Main',1,0);
$pdf->Cell(35,6,'Harga',1,0);
$pdf->Cell(35,6,'Jam Mulai',1,1);
 
$pdf->SetFont('Arial','',10);
$id = $_GET['qr_booking'];
$sql = mysqli_query($koneksi,"SELECT DISTINCT qr_booking,f_name,nama_tim,t_booking,t_main,h_lapangan,t_harga,b_awal FROM boking WHERE qr_booking='$id' ");
while ($row = mysqli_fetch_array($sql)){

	$pdf->Cell(10,6,$row['lapangan'],1,0);
    $pdf->Cell(40,6,$row['qr'],1,0);
    $pdf->Cell(43,6,$row['f_name'],1,0);
    $pdf->Cell(43,6,$row['nama_tim'],1,0);
    $pdf->Cell(35,6,$row['t_booking'],1,0);
    $pdf->Cell(35,6,$row['t_main'],1,0);
    $pdf->Cell(35,6,$row['h_lapangan'],1,0);
    $pdf->Cell(35,6,$row['b_awal'],1,1);
    
}

$pdf->Output();
?>




    