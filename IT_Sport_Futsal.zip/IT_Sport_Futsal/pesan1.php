<?php
include_once 'koneksi.php';
$id = $_POST['id'];
$f_name = $_POST['f_name'];
$l_name = $_POST['l_name'];
$t_boking  = $_POST['t_boking'];
$t_main = $_POST['t_main'];
$jam = $_POST['jam'];
$harga = $_POST['harga'];
$total_harga = $_POST['total_harga'];
$b_awal = $_POST['b_awal'];
$t_awal = $_POST['t_awal'];
$area_code = $_POST['area_code'];
$phone = $_POST['phone'];
$nama_tim = $_POST['nama_tim'];
$lp1 = 'sold';
$lapangan = 'lapangan 1';
$admin = 'admin';
$chkcount = count($id);
$qr_booking = base_convert(microtime(false), 20, 36);


for($i=0; $i<$chkcount; $i++)
{
     $sql1  = "UPDATE detail_jadwal SET lapangan1='$lp1' WHERE id_detail=$id[$i]";
     $sql2  = "INSERT INTO boking (qr_booking,id_detail,lapangan,admin,f_name,l_name,t_booking,t_main,j_main,h_lapangan,t_harga,b_awal,a_code,phone,nama_tim)
            VALUES ('$qr_booking','$id[$i]','$lapangan','$admin','$f_name','$l_name','$t_boking','$t_main','$jam[$i]','$harga','$total_harga','$b_awal','$area_code','$phone','$nama_tim')";      
     $teguh1 = mysqli_query($koneksi,$sql1);
     $teguh2 = mysqli_query($koneksi,$sql2); 
	       

     if ($teguh2 == TRUE) {     	   
	     	?>
	  			<script>

	  					alert('data berhasil di input !!!');
	  					window.location.href='index.php';
	  			</script>
 		<?php
	     } else{
	     	echo "data gagal di input";
	     } 

       
 }

?>
<?php  



 	