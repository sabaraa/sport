
<?php  
  include 'koneksi.php';
  date_default_timezone_set('Asia/Jakarta');
  $now    = date ("d-m-Y");
 ?> 
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Detail Booking</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="boking.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
</head>
<body>
    <div class="container-fluid">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-4">
            <h2>Detail Booking <b></b></h2>
          </div>
          <div class="col-sm-offset-11">
            <?php  if(isset($_GET['qr_booking'])){

                    ?>
                    <span class="btn btn-success">Your QR_booking : <?php  echo $qr_booking=$_GET['qr_booking']; ?></span>
                    <?php
                    }else{
                  
               
                    }
            
              ?>
          </div>
                </div>
            </div>
      <div class="table-filter">
        <div class="row">
          <div class="card">
            <div class="show-entries">
              
            </div>
          </div>
        </div>
     </div>

  <form method="post" name="frm">
  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
        <tr>
          <th>ID BOKING</th>
          <th>QR QODE</th>
          <th>user</th>
          <th>TIM</th>
          <th>Tgl Boking</th>
          <th>Tgl Main</th>
          <th>Harga Lapangan</th>
          <th>Harga total</th>
          <th>Bayar awal</th>
          <th>sisa bayar</th>
          <th>waktu mulai</th>
          <th>waktu selesai</th>
          <th>Lama main</th>
          <th>aksi</th>
          
        </tr>
      </thead>
      <tbody>
        <?php 
        $qr_booking = $_GET['qr_booking'];
        $sql = mysqli_query($koneksi,"SELECT * FROM boking WHERE qr_booking='$qr_booking' LIMIT 1 ");
          while($d = mysqli_fetch_array($sql)){
         ?>
        <tr>
          <td><?php echo $d['id_boking']; ?></td>
          <td><?php echo $d['qr_booking']; ?></td>
          <td><?php echo $d['f_name']; ?></td>
          <td><?php echo $d['nama_tim']; ?></td>
          <td><?php echo $d['t_booking']; ?></td>
          <td><?php echo $d['t_main']; ?></td>
          <td><?php echo $d['h_lapangan']; ?></td>
          <?php 
             if ($d['t_harga'] == $d['b_awal']) {
                ?>
                <td style="color: blue;"><?php echo $d['t_harga']; ?></td>
                <td style="color: blue;"><?php echo $d['b_awal']; ?></td>
                <?php  $a = $d['t_harga']-$d['b_awal']; ?>
                <td style="background-color: rgb(255, 255, 128); color: red; text-align: center;"><?php echo $a; ?></td>
                <?php
             }else{
                ?>
                <td style="color: red;"><?php echo $d['t_harga']; ?></td>
                <td style="color: red;"><?php echo $d['b_awal']; ?></td>
                <?php  $a = $d['t_harga']-$d['b_awal']; ?>
                <td style="background-color: rgb(255, 255, 128); color: blue; text-align: center;"><?php echo $a; ?></td>
                <?php
             }
             ?>  
      <?php } ?>
            <?php  
            $qr_booking = $_GET['qr_booking'];
            $a = mysqli_query($koneksi,"SELECT j_main, MIN(j_main) FROM boking WHERE qr_booking='$qr_booking'");

             while($yong = mysqli_fetch_array($a)){
         ?>
            <?php  
            if ($yong['j_main'] <= 15) {
              ?>
              <td><?php echo $yong['j_main'] + 0; ?> : PM </td>
              <?php
            }elseif ($yong['j_main']  >= 15) {
              ?>
              <td><?php echo $yong['j_main'] + 0; ?> : AM</td>
              <?php
            }else{
              echo "error";
            }
            ?>
 
      <?php  } ?>
       <?php  
            $qr_booking = $_GET['qr_booking'];
            $b = mysqli_query($koneksi,"SELECT j_main, MIN(j_main) FROM boking WHERE qr_booking='$qr_booking'");
             while($yeng = mysqli_fetch_array($b)){
           ?>
            <?php  
            if ($yeng['j_main'] >= 15 ) {
              ?>
              <td><?php 
              $qr_booking = $_GET['qr_booking'];
              $sqlCommand = "SELECT COUNT(j_main) FROM boking WHERE qr_booking='$qr_booking'"; 
              $query = mysqli_query($koneksi, $sqlCommand) or die (mysqli_error()); 
              $row = mysqli_fetch_row($query);

              echo $yeng['j_main'] + $row[0]; ?> : PM</td>
              <?php
            }elseif ($yeng['j_main']  <= 14) {
              ?>
              <td><?php 
              $qr_booking = $_GET['qr_booking'];
              $sqlCommand = "SELECT COUNT(j_main) FROM boking WHERE qr_booking='$qr_booking'"; 
              $query = mysqli_query($koneksi, $sqlCommand) or die (mysqli_error()); 
              $row = mysqli_fetch_row($query);
              echo $yeng['j_main'] + $row[0]; ?> : AM</td>
              <?php
            }else{
              echo "error";
            }
          ?>
          <td><?php  echo $row[0]; ?> Jam</td>
            
            <td>
            <div class="dropdown">
             <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" style="background: green">-pilih-
              <span class="caret"></span></button>
              <ul class="dropdown-menu">
               <li><a href="detail1.php?qr_booking=<?php echo $d['qr_booking']; ?>">bayar</a></li>
               <li><a href="riwayat_booking.php">Kembali</a></li>
              </ul>
            </div>
          </td> 
        </tr>
     <?php  } ?>
      </tbody>
    </table>
    <hr> 
      <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Developer &copy; 2019 - Teguh Sabara</div>
    </div>
  </footer>
  </div>
</div> 

</body>
</form>
</html>                                                               
