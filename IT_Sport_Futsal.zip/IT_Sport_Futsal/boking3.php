
<?php
 include_once 'koneksi.php';
  session_start();
 
    // cek apakah yang mengakses halaman ini sudah login
    if($_SESSION['status']=="superman"){
        
    }else{
        header("location:index.php?pesan=gagal");
}
 if(isset($_POST['chk'])=="")
 {
  ?>
  <script>

  alert('At least one checkbox Must be Selected !!!');
  window.location.href='lapangan1.php';
  </script>
 <?php
 }
 $chk = $_POST['chk'];
 $chkcount = count($chk);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Au Register Forms by Colorlib</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">Booking Form</h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="pesan3.php">
                        <div class="form-row m-b-55">
                            <div class="name">Name</div>
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="f_name" placeholder="Wajib di isi" required="isi">
                                            <label class="label--desc">first name</label>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="l_name"placeholder="Wajib di isi" required="isi">
                                            <label class="label--desc">last name</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Tgl Booking</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="date" name="t_boking">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Tgl Main</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="date" name="t_main" value="">
                                </div>
                            </div>
                        </div>
                        <?php
                            for($i=0; $i<$chkcount; $i++)
                            {
                             $id = $chk[$i];   
                             $res=$koneksi->query("SELECT * FROM detail_jadwal WHERE id_detail='$id'");
                             while($row=$res->fetch_array())
                             {
                        ?>    
                        <input type="text" name="id[]" value="<?php echo $row['id_detail'];?>"  hidden/>                
                        <div class="form-row">
                            <div class="name">Jam Main</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="time" name="jam[]" value="<?php echo $row['jam'] ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <?php 
                          }  
                         }  
                      ?>
                        <div class="form-row">
                            <div class="name">Harga / Jam</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="harga" value="100000" id="harga" readonly>
                                </div>
                            </div>
                        </div>
                         <div class="form-row">
                            <div class="name">Lama Main</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="total_jam" id="total_jam" value="<?php echo $chkcount; ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Total harga</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5 total_harga" type="text" name="total_harga" id="total_harga" onkeyup="hitung();" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Bayar awal</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5 b_awal" type="text" name="b_awal" id="b_awal" placeholder="Wajib di isi" onkeyup="hitung();" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Total awal</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5 t_awal" type="text" name="t_awal" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="form-row m-b-55">
                            <div class="name">Phone</div>
                            <div class="value">
                                <div class="row row-refine">
                                    <div class="col-3">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="area_code">
                                            <label class="label--desc">Area Code</label>
                                        </div>
                                    </div>
                                    <div class="col-9">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="phone" placeholder="Wajib di isi" required="">
                                            <label class="label--desc">Phone Number</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Nama Team</div>
                            <div class="value">
                                <div class="input-group">
                                  <input class="input--style-5" type="text" name="nama_tim" placeholder="Wajib di isi" required=""></div>
                            </div>
                        </div>
                        <div>
                            <button class="btn btn--radius-2 btn--red" type="submit" name="save">Booking</button>
                            <a href="lapangan1.php" class="btn btn--radius-2 btn--blue">back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>
    <script type="text/javascript">
            $(document).ready(function() {
                
                var harga=parseInt($('#harga').val());
                var total_jam=parseInt($('#total_jam').val());
                var total_jam=parseInt($('#total_jam').val());
                var total_harga = harga*total_jam;
                $('#total_harga').val(total_harga);

            });
              function hitung() {
                    var total_harga = $(".total_harga").val();
                    var b_awal = $(".b_awal").val();
                            c = b_awal - total_harga; //a kali b
                    $(".t_awal").val(c);
                }
    </script>
           

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->